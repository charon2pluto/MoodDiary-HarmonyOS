if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    moods?: MoodItem[];
    currentDate?: string;
    selectedMoodIndex?: number;
    moodScore?: number;
    reasonText?: string;
}
import router from "@ohos:router";
import MoodDB from "@normalized:N&&&entry/src/main/ets/utils/MoodDB&";
import MoodData from "@normalized:N&&&entry/src/main/ets/model/MoodData&";
import type { BusinessError as BusinessError } from "@ohos:base";
import type common from "@ohos:app.ability.common";
// 1. 定义一个“模具”，告诉系统每个心情选项必须有 icon 和 name
interface MoodItem {
    icon: string;
    name: string;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.moods = [
            { icon: '😄', name: '开心' },
            { icon: '😐', name: '平静' },
            { icon: '😰', name: '焦虑' },
            { icon: '😢', name: '伤心' },
            { icon: '😡', name: '生气' },
            { icon: '😴', name: '疲惫' },
            { icon: '🤩', name: '兴奋' },
            { icon: '🤯', name: '烦躁' }
        ];
        this.__currentDate = new ObservedPropertySimplePU('', this, "currentDate");
        this.__selectedMoodIndex = new ObservedPropertySimplePU(-1, this, "selectedMoodIndex");
        this.__moodScore = new ObservedPropertySimplePU(5, this, "moodScore");
        this.__reasonText = new ObservedPropertySimplePU('', this, "reasonText");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.moods !== undefined) {
            this.moods = params.moods;
        }
        if (params.currentDate !== undefined) {
            this.currentDate = params.currentDate;
        }
        if (params.selectedMoodIndex !== undefined) {
            this.selectedMoodIndex = params.selectedMoodIndex;
        }
        if (params.moodScore !== undefined) {
            this.moodScore = params.moodScore;
        }
        if (params.reasonText !== undefined) {
            this.reasonText = params.reasonText;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentDate.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedMoodIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__moodScore.purgeDependencyOnElmtId(rmElmtId);
        this.__reasonText.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentDate.aboutToBeDeleted();
        this.__selectedMoodIndex.aboutToBeDeleted();
        this.__moodScore.aboutToBeDeleted();
        this.__reasonText.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 2. 心情数据源
    private moods: MoodItem[];
    private __currentDate: ObservedPropertySimplePU<string>;
    get currentDate() {
        return this.__currentDate.get();
    }
    set currentDate(newValue: string) {
        this.__currentDate.set(newValue);
    }
    private __selectedMoodIndex: ObservedPropertySimplePU<number>;
    get selectedMoodIndex() {
        return this.__selectedMoodIndex.get();
    }
    set selectedMoodIndex(newValue: number) {
        this.__selectedMoodIndex.set(newValue);
    }
    private __moodScore: ObservedPropertySimplePU<number>;
    get moodScore() {
        return this.__moodScore.get();
    }
    set moodScore(newValue: number) {
        this.__moodScore.set(newValue);
    }
    private __reasonText: ObservedPropertySimplePU<string>;
    get reasonText() {
        return this.__reasonText.get();
    }
    set reasonText(newValue: string) {
        this.__reasonText.set(newValue);
    }
    aboutToAppear() {
        const date = new Date();
        // 格式化日期：X月X日
        this.currentDate = `${date.getMonth() + 1}月${date.getDate()}日`;
        // getContext(this) 获取当前的上下文环境
        let context = getContext(this) as common.UIAbilityContext;
        MoodDB.init(context).then(() => {
            console.log('🎉 主页：数据库连接成功！');
        }).catch((err: Error) => {
            console.error('😭 主页：数据库连接失败', err);
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(47:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // --- 顶部日期 ---
            Text.create(this.currentDate);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(49:7)", "entry");
            // --- 顶部日期 ---
            Text.fontSize(28);
            // --- 顶部日期 ---
            Text.fontWeight(FontWeight.Bold);
            // --- 顶部日期 ---
            Text.margin({ top: 40, bottom: 10 });
            // --- 顶部日期 ---
            Text.width('100%');
            // --- 顶部日期 ---
            Text.padding({ left: 20 });
        }, Text);
        // --- 顶部日期 ---
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('今天过得怎么样？');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(56:7)", "entry");
            Text.fontSize(18);
            Text.fontColor('#666');
            Text.width('100%');
            Text.padding({ left: 20, bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // --- 中间 Emoji 选择网格 ---
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/Index.ets(63:7)", "entry");
            // --- 中间 Emoji 选择网格 ---
            Grid.columnsTemplate('1fr 1fr 1fr 1fr');
            // --- 中间 Emoji 选择网格 ---
            Grid.rowsGap(15);
            // --- 中间 Emoji 选择网格 ---
            Grid.height(200);
            // --- 中间 Emoji 选择网格 ---
            Grid.width('95%');
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/pages/Index.ets(65:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/Index.ets(66:13)", "entry");
                            Column.width(70);
                            Column.height(80);
                            Column.justifyContent(FlexAlign.Center);
                            Column.borderRadius(16);
                            Column.backgroundColor(this.selectedMoodIndex === index ? '#E3F2FD' : '#FFFFFF');
                            Column.border({ width: 2, color: this.selectedMoodIndex === index ? '#2196F3' : 'transparent' });
                            Column.onClick(() => {
                                this.selectedMoodIndex = index;
                            });
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.icon);
                            Text.debugLine("entry/src/main/ets/pages/Index.ets(67:15)", "entry");
                            Text.fontSize(40);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.name);
                            Text.debugLine("entry/src/main/ets/pages/Index.ets(68:15)", "entry");
                            Text.fontSize(14);
                            Text.fontColor('#666');
                            Text.margin({ top: 5 });
                        }, Text);
                        Text.pop();
                        Column.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.moods, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // --- 中间 Emoji 选择网格 ---
        Grid.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // --- 选中后的详细输入区 ---
            if (this.selectedMoodIndex !== -1) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(89:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Divider.create();
                        Divider.debugLine("entry/src/main/ets/pages/Index.ets(90:11)", "entry");
                        Divider.margin({ top: 20, bottom: 20 });
                    }, Divider);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/Index.ets(92:11)", "entry");
                        Row.width('90%');
                        Row.margin({ bottom: 15 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('强度: ' + this.moodScore);
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(93:13)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Bold);
                        Text.width(70);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Slider.create({
                            value: this.moodScore,
                            min: 1,
                            max: 10,
                            step: 1,
                            style: SliderStyle.OutSet
                        });
                        Slider.debugLine("entry/src/main/ets/pages/Index.ets(94:13)", "entry");
                        Slider.layoutWeight(1);
                        Slider.showSteps(true);
                        Slider.onChange((value: number) => {
                            this.moodScore = value;
                        });
                    }, Slider);
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '一句话记录原因 (可选)...' });
                        TextInput.debugLine("entry/src/main/ets/pages/Index.ets(108:11)", "entry");
                        TextInput.width('90%');
                        TextInput.height(50);
                        TextInput.backgroundColor('#F5F5F5');
                        TextInput.borderRadius(12);
                        TextInput.onChange((value) => {
                            this.reasonText = value;
                        });
                        TextInput.margin({ bottom: 30 });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('记录心情', { type: ButtonType.Capsule });
                        Button.debugLine("entry/src/main/ets/pages/Index.ets(118:11)", "entry");
                        Button.width('80%');
                        Button.height(50);
                        Button.backgroundColor('#7B61FF');
                        Button.onClick(() => {
                            this.saveData();
                        });
                    }, Button);
                    Button.pop();
                    Column.pop();
                });
            }
            // --- 这里的 Blank 会自动撑开空间，把下面的按钮推到屏幕最底部 ---
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // --- 这里的 Blank 会自动撑开空间，把下面的按钮推到屏幕最底部 ---
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(129:7)", "entry");
        }, Blank);
        // --- 这里的 Blank 会自动撑开空间，把下面的按钮推到屏幕最底部 ---
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // --- 底部历史记录入口 ---
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(132:7)", "entry");
            // --- 底部历史记录入口 ---
            Row.width('100%');
            // --- 底部历史记录入口 ---
            Row.justifyContent(FlexAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('查看心情足迹 📅');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(133:9)", "entry");
            Button.backgroundColor('#F0F0F0');
            Button.fontColor('#333');
            Button.width('90%');
            Button.height(50);
            Button.margin({ bottom: 20 });
            Button.onClick(() => {
                // 跳转到历史页
                router.pushUrl({ url: 'pages/MoodHistory' });
            });
        }, Button);
        Button.pop();
        // --- 底部历史记录入口 ---
        Row.pop();
        Column.pop();
    }
    // 保存数据到数据库
    saveData() {
        let newMood = new MoodData(0, new Date().getTime(), this.selectedMoodIndex, this.moodScore, this.reasonText, '', '');
        MoodDB.insert(newMood).then((id) => {
            AlertDialog.show({ message: '✨ 记录成功！' });
            // 保存成功后重置页面状态
            this.selectedMoodIndex = -1;
            this.reasonText = '';
            this.moodScore = 5;
        }).catch((err: BusinessError) => {
            AlertDialog.show({ message: '保存失败: ' + err.message });
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.mooddiary", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
