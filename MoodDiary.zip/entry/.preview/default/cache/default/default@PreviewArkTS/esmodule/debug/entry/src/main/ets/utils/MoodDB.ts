import relationalStore from "@ohos:data.relationalStore";
import type common from "@ohos:app.ability.common";
import type { BusinessError as BusinessError } from "@ohos:base";
import MoodData from "@normalized:N&&&entry/src/main/ets/model/MoodData&";
export default class MoodDB {
    private static rdbStore: relationalStore.RdbStore | undefined = undefined;
    // 1. 把建表语句直接放在这里，方便管理
    private static readonly SQL_CREATE_TABLE = 'CREATE TABLE IF NOT EXISTS MOOD_TABLE (id INTEGER PRIMARY KEY AUTOINCREMENT, date INTEGER, moodType INTEGER, moodScore INTEGER, reason TEXT, diaryContent TEXT, images TEXT)';
    // 2. 新增一个初始化方法：给它一个 Context，它就负责把数据库准备好
    static init(context: common.UIAbilityContext): Promise<void> {
        if (MoodDB.rdbStore) {
            // 如果已经初始化过了，直接成功
            return Promise.resolve();
        }
        const STORE_CONFIG: relationalStore.StoreConfig = {
            name: 'MoodDiary.db',
            securityLevel: relationalStore.SecurityLevel.S1
        };
        return new Promise((resolve, reject) => {
            relationalStore.getRdbStore(context, STORE_CONFIG, (err, store) => {
                if (err) {
                    console.error(`DB Init Failed: ${err.message}`);
                    reject(err);
                    return;
                }
                // 执行建表
                if (store) {
                    store.executeSql(MoodDB.SQL_CREATE_TABLE);
                    MoodDB.rdbStore = store;
                    console.info('✅ 数据库初始化成功！');
                    resolve();
                }
            });
        });
    }
    // 3. 插入方法（保持不变，但加了更详细的报错）
    static async insert(mood: MoodData): Promise<number> {
        if (!MoodDB.rdbStore) {
            return Promise.reject(new Error('💥 数据库还没准备好，请重启 App 试试'));
        }
        const valueBucket: relationalStore.ValuesBucket = {
            'date': mood.date,
            'moodType': mood.moodType,
            'moodScore': mood.moodScore,
            'reason': mood.reason,
            'diaryContent': mood.diaryContent,
            'images': mood.images
        };
        return MoodDB.rdbStore.insert('MOOD_TABLE', valueBucket);
    }
    // 4. 查询方法
    static queryAll(): Promise<Array<MoodData>> {
        let predicates = new relationalStore.RdbPredicates('MOOD_TABLE');
        predicates.orderByDesc('date');
        return new Promise<Array<MoodData>>((resolve, reject) => {
            if (!MoodDB.rdbStore) {
                resolve([]); // 没准备好就返回空，不报错
                return;
            }
            MoodDB.rdbStore.query(predicates).then((resultSet) => {
                let moodList = new Array<MoodData>();
                while (resultSet.goToNextRow()) {
                    moodList.push(new MoodData(resultSet.getLong(resultSet.getColumnIndex('id')), resultSet.getLong(resultSet.getColumnIndex('date')), resultSet.getLong(resultSet.getColumnIndex('moodType')), resultSet.getLong(resultSet.getColumnIndex('moodScore')), resultSet.getString(resultSet.getColumnIndex('reason')), resultSet.getString(resultSet.getColumnIndex('diaryContent')), resultSet.getString(resultSet.getColumnIndex('images'))));
                }
                resultSet.close();
                resolve(moodList);
            }).catch((err: BusinessError) => {
                reject(err);
            });
        });
    }
}
