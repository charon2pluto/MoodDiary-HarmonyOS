// 文件位置: entry/src/main/ets/model/MoodData.ets
export default class MoodData {
    id: number | null = null;
    date: number; // 记录日期的时间戳
    moodType: number; // 心情类型 (比如 0代表开心, 1代表难过)
    moodScore: number; // 心情强度 (1-10分)
    reason: string; // 简短原因
    diaryContent: string; // 日记正文
    images: string; // 图片路径
    constructor(id: number, date: number, moodType: number, moodScore: number, reason: string, diaryContent: string, images: string) {
        this.id = id;
        this.date = date;
        this.moodType = moodType;
        this.moodScore = moodScore;
        this.reason = reason;
        this.diaryContent = diaryContent;
        this.images = images;
    }
}
