if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MoodHistory_Params {
    historyList?: MoodData[];
    moods?: MoodItem[];
}
import router from "@ohos:router";
import MoodDB from "@normalized:N&&&entry/src/main/ets/utils/MoodDB&";
import type MoodData from '../model/MoodData';
// 1. 同样需要定义这个接口 (为了规范，最好以后提取到单独文件，现在先复制过来用)
interface MoodItem {
    icon: string;
    name: string;
}
class MoodHistory extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__historyList = new ObservedPropertyObjectPU([], this, "historyList");
        this.moods = [
            { icon: '😄', name: '开心' },
            { icon: '😐', name: '平静' },
            { icon: '😰', name: '焦虑' },
            { icon: '😢', name: '伤心' },
            { icon: '😡', name: '生气' },
            { icon: '😴', name: '疲惫' },
            { icon: '🤩', name: '兴奋' },
            { icon: '🤯', name: '烦躁' }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MoodHistory_Params) {
        if (params.historyList !== undefined) {
            this.historyList = params.historyList;
        }
        if (params.moods !== undefined) {
            this.moods = params.moods;
        }
    }
    updateStateVars(params: MoodHistory_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__historyList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__historyList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __historyList: ObservedPropertyObjectPU<MoodData[]>;
    get historyList() {
        return this.__historyList.get();
    }
    set historyList(newValue: MoodData[]) {
        this.__historyList.set(newValue);
    }
    // 2. 这里把 any[] 改成 MoodItem[]
    private moods: MoodItem[];
    onPageShow() {
        // 页面显示时查询数据库
        MoodDB.queryAll().then((data) => {
            this.historyList = data;
        });
    }
    // 格式化时间戳
    formatDate(timestamp: number): string {
        const date = new Date(timestamp);
        // 补零操作，比如 8:5 变成 08:05
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        return `${month}月${day}日 ${hours}:${minutes}`;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/MoodHistory.ets(47:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#F5F7F9');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // --- 顶部导航栏 ---
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/MoodHistory.ets(49:7)", "entry");
            // --- 顶部导航栏 ---
            Row.width('100%');
            // --- 顶部导航栏 ---
            Row.padding({ left: 20, right: 20, top: 15, bottom: 15 });
            // --- 顶部导航栏 ---
            Row.backgroundColor('#FFFFFF');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('< 返回');
            Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(50:9)", "entry");
            Text.fontSize(18);
            Text.fontColor('#007DFF');
            Text.onClick(() => {
                router.back();
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('心情足迹');
            Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(57:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 20 });
        }, Text);
        Text.pop();
        // --- 顶部导航栏 ---
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // --- 列表区域 ---
            // 如果没有数据，显示一个提示
            if (this.historyList.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MoodHistory.ets(69:9)", "entry");
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('还没有记录心情哦~');
                        Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(70:11)", "entry");
                        Text.fontColor('#999');
                        Text.margin({ top: 100 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 12 });
                        List.debugLine("entry/src/main/ets/pages/MoodHistory.ets(75:9)", "entry");
                        List.width('95%');
                        List.layoutWeight(1);
                        List.margin({ top: 10 });
                        List.scrollBar(BarState.Auto);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/MoodHistory.ets(77:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/MoodHistory.ets(78:15)", "entry");
                                        Row.width('100%');
                                        Row.padding(15);
                                        Row.backgroundColor('#FFFFFF');
                                        Row.borderRadius(16);
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 左边：表情
                                        // 3. 这里加个安全判断，防止数组越界
                                        Text.create(this.moods[item.moodType] ? this.moods[item.moodType].icon : '❓');
                                        Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(81:17)", "entry");
                                        // 左边：表情
                                        // 3. 这里加个安全判断，防止数组越界
                                        Text.fontSize(40);
                                        // 左边：表情
                                        // 3. 这里加个安全判断，防止数组越界
                                        Text.margin({ right: 15 });
                                    }, Text);
                                    // 左边：表情
                                    // 3. 这里加个安全判断，防止数组越界
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 中间：信息
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/MoodHistory.ets(86:17)", "entry");
                                        // 中间：信息
                                        Column.alignItems(HorizontalAlign.Start);
                                        // 中间：信息
                                        Column.layoutWeight(1);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(this.formatDate(item.date));
                                        Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(87:19)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor('#999');
                                        Text.margin({ bottom: 5 });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.reason ? item.reason : '（未填写原因）');
                                        Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(92:19)", "entry");
                                        Text.fontSize(16);
                                        Text.fontColor('#333');
                                        Text.maxLines(1);
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                    }, Text);
                                    Text.pop();
                                    // 中间：信息
                                    Column.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 右边：分数
                                        Text.create(item.moodScore + '分');
                                        Text.debugLine("entry/src/main/ets/pages/MoodHistory.ets(102:17)", "entry");
                                        // 右边：分数
                                        Text.fontSize(18);
                                        // 右边：分数
                                        Text.fontWeight(FontWeight.Bold);
                                        // 右边：分数
                                        Text.fontColor('#7B61FF');
                                    }, Text);
                                    // 右边：分数
                                    Text.pop();
                                    Row.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.historyList, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MoodHistory";
    }
}
registerNamedRoute(() => new MoodHistory(undefined, {}), "", { bundleName: "com.example.mooddiary", moduleName: "entry", pagePath: "pages/MoodHistory", pageFullPath: "entry/src/main/ets/pages/MoodHistory", integratedHsp: "false", moduleType: "followWithHap" });
